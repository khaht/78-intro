window.service_endpoint = 'http://43.255.28.160/api';
